//Includes for this program
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


void error(const char *msg){ 
  //Print the message sent into this
  perror(msg);
  //Exit
  exit(1);
}



int main(int argc, char* argv[]) {
  //Variables used for this function
  int listenSocketFD;
  int establishedConnectionFD;
  int portNumber;
  int charsRead;
  int charsWritten;
  int inputLength;
  int i;
  int j;
  int k;
  int l;
  int m;
  int encInt;
  int keyInt;
  int theSecret;
  char character;
  char tempString[5];
  char msgToEnc;
  char msgKey;
  char buffer[256];
  socklen_t sizeOfClientInfo;
  struct sockaddr_in serverAddress;
  struct sockaddr_in clientAddress;



  //If not all the arguments are read in
  if (argc < 2) {
    //Print an error
    fprintf(stderr,"USAGE: %s port\n", argv[0]);
    //Exit
    exit(1);
  }



  //Set up the address struct for this process
  //Clear out the address struct
  memset((char *)&serverAddress, '\0', sizeof(serverAddress));
  //Get the port number
  portNumber = atoi(argv[1]);



  //Create a netowkr-capable socket
  serverAddress.sin_family = AF_INET;
  //Store the port number
  serverAddress.sin_port = htons(portNumber);
  //Aby address is allowed for connection in this process
  serverAddress.sin_addr.s_addr = INADDR_ANY;



  //Set up the socket
  //Create the socket
  listenSocketFD = socket(AF_INET, SOCK_STREAM, 0);
  //If it's not made
  if (listenSocketFD < 0){
	  //Send an error
	  error("ERROR opening socket");
  }

  //Enable the socket to begin listening
  //Connect socket to port; if it doesn't listen
  if (bind(listenSocketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){
	  //Send an error
	  error("ERROR on binding");
  }

  //Flip the socket on
  listen(listenSocketFD, 5);



  //While we want it to run
  while(1){
	  //Accept a connection
	  //Get size of the address
	  sizeOfClientInfo = sizeof(clientAddress);
	  //Accept
	  establishedConnectionFD = accept(listenSocketFD, (struct sockaddr*)&clientAddress, &sizeOfClientInfo);
	  //If it cannot accept
	  if (establishedConnectionFD < 0){
		  //Send an error
		  error("ERROR on accept");
	  }



	  //Fork
  	  pid_t listenForNew = fork();

	  //If it didn't fork properly
	  if(listenForNew < 0){
		  //Send an error
		  perror("Unable to create another incoming connection.");
	  }
	  //If it is successful
	  else if(listenForNew == 0){
		  //Clear out the buffer
		  for(m = 0; m < 256; m++){
			buffer[m] = '\0';
		  }



		  //Recerive a message
		  charsRead = recv(establishedConnectionFD, buffer, 1, 0);
		  //If it didn't receive anything
		  if(charsRead < 0){
			//Send an error
			error("SERVER: ERROR reading to socket");
		  }
		  //If it received a D
		  if(strcmp(buffer, "D") == 0){
			//Send back that it's in the right file
			charsWritten = send(establishedConnectionFD, "Y", 1, 0);
			//If it didn't send
			if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			}
		  }
		  //If it received an E
		  if(strcmp(buffer, "E") == 0){
			//Send back that it's not in the right file
			charsWritten = send(establishedConnectionFD, "N", 1, 0);
			//If it didn't send anything
			if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			}
		  }



		  //Receive the length of the message
		  charsRead = recv(establishedConnectionFD, buffer, 255, 0);
		  //If it didn't receive anything
		  if (charsRead < 0){
			  //Send an error
			  error("SERVER: ERROR reading from socket");
		  }


		  //For the size of the verification I sent
		  for(i = 0; i < 5; i++){
			//Make a string of the message
			character = buffer[i];

			tempString[i] = character;
		  }

		  //If the string matches "got it"
		  if(strcmp(tempString, "gotit") == 0){

			  //Get the length of the encryption which was after the message
			  inputLength = atoi(&buffer[5]);



			  //Send a sucess message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If it didn't send
			  if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			  }


			  //Create a string for the message
			  char encMsg[inputLength];
			  //Set the memory to \0
			  memset(encMsg, '\0', inputLength);
			  //Create a string for the key
			  char keyMsg[inputLength];
			  //Set the memory to \0
			  memset(keyMsg, '\0', inputLength);



			  //Clear the charsread
			  charsRead = 0;
			  //While not everything has been read in
			  while(charsRead < inputLength){
				  //Read in the encrypted message
				  charsRead += recv(establishedConnectionFD, &encMsg[charsRead], inputLength - charsRead, 0);
				  //If it didn't read the message
				  if (charsRead < 0){
					  //Send an error
					  error("SERVER: ERROR reading to socket");
			  	}
			  }

			  //Send a success message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If nothing selds
			  if(charsWritten < 0){
				  //Send an error
				  error("SERVER: ERROR writing to socket");
			  }



			  //Clear the charsread
			  charsRead = 0;
			  //While not everything has been read
		  	  while(charsRead < inputLength){
				  //Read in the key
				  charsRead += recv(establishedConnectionFD, &keyMsg[charsRead], inputLength - charsRead, 0);
				  //If nothing is read
				  if(charsRead < 0){
					  //Send an error
					  error("SERVER: ERROR reading to socket");
				  }
			  }

			  //Send a success message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If nothing is sent
			  if(charsWritten < 0){
				  //Send an error
				  error("SERVER: ERROR writing to socket");
			  }



			  //Make a string to put the decrypted message in
			  char justWork[inputLength];
			  //Set the memory to \0
			  memset(justWork, '\0', inputLength);



			  //For the length of the message
			  for(l = 0; l < inputLength; l++){

				//Take in the first character
				encInt = (int)encMsg[l];
				//Take in the first character
				keyInt = (int)keyMsg[l];

				//Subtract A
				encInt = encInt - (int)'A';
				//Subtract A
				keyInt = keyInt - (int)'A';

				//If it's less than 0 its a space
				if(encInt < 0){
					//Make the int a space
					encInt = 26;
				}
				//If it's less than 0 it's a space
				if(keyInt < 0){
					//Make the int a space
					keyInt = 26;
				}

				//Subtract the key from the message
				theSecret = encInt - keyInt;

				//If it's less than 0 add 27
				if(theSecret < 0){
					theSecret = theSecret + 27;
				}

				//Mod it by 27
				theSecret = theSecret % 27;

				//Add A back into it
				theSecret = theSecret + (int)'A';

				//It the int is equal to 91 it's a space
				if(theSecret == 91){
					//Make the character a space
					theSecret = (int)' ';
				}

				//Put that character into the string
				justWork[l] = (char)theSecret;
			  }



			  //Clear the charswritten
			  charsWritten = 0;
			  //While not everything has been sent
			  while(charsWritten < inputLength){
				  //Send over the decrypted message
				  charsWritten += send(establishedConnectionFD, justWork, inputLength - charsWritten, 0);
				  //If nothing gets sent
				  if(charsWritten < 0){
					//Send a message
					error("ERROR writing to socket");
				  }
			  }



			  //Close the thing
			  close(establishedConnectionFD);
			  

			  //Exit out of the while loop
			  return 0;
	  	}
		else{
			//Close the thing
			close(establishedConnectionFD);
			

			//Keep going
			return (1);
		}
	  }
 }
  //Stop listening
  close(listenSocketFD);



  //Close everything
  return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


int main(int argc, char* argv[]){
	//Initialize varibales needed for this function
	int i;
	int j;
	int randNum;
	int userLength;
	char* keygenArray;
	char* userInput;


	//Set up for randomizing a number
	srand(time(NULL));


	//Use atoi to get the length the user wants the string to be
	userLength = atoi(argv[1]);


	//Make the array the size of the user's inputed length
	keygenArray = (char*) malloc(sizeof(char) * userLength);


	//For the number inputed by the user
	for(i = 0; i < userLength; i++){
		//Randomize a number between 0 and 26
		randNum = (rand() % (25 - 0 + 1)) + 0;
		//Add 65 so the letter or space is the correct ascii value
		randNum += 65;

		//0-25 + 65 will give the ascii values of A-Z. That means 26 +
		//65 will be the space
		//If the number is equal to 91
		if(randNum == 91){
			//It is a space so make it a space
			keygenArray[i] = ' ';
		//else...
		}else{
			//Make the the index the number of the character
			keygenArray[i] = (char)randNum;
		}
	}


	//Print the array of random characters
	printf("%s\n", keygenArray);


	//For the length of the array that was just printed
	for(j = 0; j < userLength; j++){
		//Clear the array
		keygenArray[j] = '\0';
	}


	//Return 0
	return 0;
}

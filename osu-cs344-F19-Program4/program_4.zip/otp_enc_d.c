//Includes for this program
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


void error(const char *msg) {
  //Print the error message sent into this function
  perror(msg);
  //Exit
  exit(1);
}


int main(int argc, char* argv[]) {
  //Variables for this function
  int listenSocketFD;
  int establishedConnectionFD;
  int portNumber;
  int charsRead;
  int charsWritten;
  int inputLength;
  int i;
  int j;
  int k;
  int l;
  int m;
  int encInt;
  int keyInt;
  int theSecret;
  char character;
  char tempString[5];
  char msgToEnc;
  char msgKey;
  char buffer[256];
  socklen_t sizeOfClientInfo;
  struct sockaddr_in serverAddress;
  struct sockaddr_in clientAddress;



  //If there are not enough arguments
  if (argc < 2) {
    //Print an error
    fprintf(stderr,"USAGE: %s port\n", argv[0]);
    //Exit
    exit(1);
  }



  //Set up the address struct for this process
  //Clear out the address struct
  memset((char *)&serverAddress, '\0', sizeof(serverAddress));



  //Get the port number
  portNumber = atoi(argv[1]);
  


  //Create a network-capable socket
  serverAddress.sin_family = AF_INET;
  //Store the port number
  serverAddress.sin_port = htons(portNumber);
  //Any address is allowed for connection to this process
  serverAddress.sin_addr.s_addr = INADDR_ANY;



  //Set up the socket
  //Create the socket
  listenSocketFD = socket(AF_INET, SOCK_STREAM, 0);
  //If the socket wasn't made
  if (listenSocketFD < 0){
	  //Send an error
	  error("ERROR opening socket");
  }

  //Enable the socket to begin listening
  //Connect socket to port; If it isn't connected
  if (bind(listenSocketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){
	  //Send an error
	  error("ERROR on binding");
  }

  //Flip the socket on
  listen(listenSocketFD, 5);



  //While we still want it to run
  while(1){
	  //Accept the connection if there is one available
	  //Get the size of the thing it's accepting
	  sizeOfClientInfo = sizeof(clientAddress);
	  //Accept it
	  establishedConnectionFD = accept(listenSocketFD, (struct sockaddr*)&clientAddress, &sizeOfClientInfo);
	  //If it isn't accpeted properly
	  if (establishedConnectionFD < 0){
		  //Send an error
		  error("ERROR on accept");
	  }



	  //Fork it
  	  pid_t listenForNew = fork();
	  //If the fork wasn't forked properly
	  if(listenForNew < 0){
		  //Print out an error
		  perror("Unable to create another incoming connection.");	
	  }
	  //Else if it forks properly
	  else if(listenForNew == 0){
		  //Clear out the buffer
		  for(m = 0; m < 256; m++){
			buffer[m] = '\0';
		  }



		  //Receive a message
		  charsRead = recv(establishedConnectionFD, buffer, 1, 0);
		  //If it's not reveiced properly
		  if(charsRead < 0){
			//Send an error
			error("SERVER: ERROR reading to socket");
		  }
		  //If it receives an E
		  if(strcmp(buffer, "E") == 0){
			//Send a Y because it is the encryption file
			charsWritten = send(establishedConnectionFD, "Y", 1, 0);
			//If it doesn't send properly
			if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			}
		  }
		  //If it receives a D
		  if(strcmp(buffer, "D") == 0){
			//Send a N becuase it is not the decryption file
			charsWritten = send(establishedConnectionFD, "N", 1, 0);
			//If it doesn't send properly
			if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			}
		  }


		  
		  //Receive the length with a verification message
		  charsRead = recv(establishedConnectionFD, buffer, 255, 0);
		  //If it doesn't receive properly
		  if (charsRead < 0){
			  //Send an error
			  error("SERVER: ERROR reading from socket");
		  }

		  //For the length of the message I send
		  for(i = 0; i < 5; i++){
			//Put it into a string
			character = buffer[i];
			tempString[i] = character;
		  }

		  //If the string I just made says "got it"
		  if(strcmp(tempString, "gotit") == 0){

			  //Get the length of the plaintext message which was
			  //send after the verification
			  inputLength = atoi(&buffer[5]);


			  
			  //Send a success message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If it doesn't send properly
			  if(charsWritten < 0){
				//Send an error
				error("SERVER: ERROR writing to socket");
			  }



			  //Make a plaintext string
			  char encMsg[inputLength];
			  //Initialize it to \0
			  memset(encMsg, '\0', inputLength);

			  //Make a key string
			  char keyMsg[inputLength];
			  //Initialize it to \0
			  memset(keyMsg, '\0', inputLength);



			  //Clear out charsread
			  charsRead = 0;
			  //While the charsread is less than the length of the
			  //message
			  while(charsRead < inputLength){
				  //Receive the plaintext
				  charsRead += recv(establishedConnectionFD, &encMsg[charsRead], inputLength - charsRead, 0);
				  //If it doesn't receive properly
				  if (charsRead < 0){
					  //Send an error
					  error("SERVER: ERROR reading to socket");
			  	}
			  }

			  //Send a success message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If it doesn't send properly
			  if(charsWritten < 0){
				  //Send an error
				  error("SERVER: ERROR writing to socket");
			  }



			  //Clear out the carsread
			  charsRead = 0;
			  //While the charsread is less than the length of the
			  //key
		  	  while(charsRead < inputLength){
				  //Receive the key
				  charsRead += recv(establishedConnectionFD, &keyMsg[charsRead], inputLength - charsRead, 0);
				  //If it doesn't receive properly
				  if(charsRead < 0){
					  //Send an error
					  error("SERVER: ERROR reading to socket");
				  }
			  }
			  
			  //Send a success message
			  charsWritten = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
			  //If it doesn't send properly
			  if(charsWritten < 0){
				  //Send an error
				  error("SERVER: ERROR writing to socket");
			  }



			  //Make a string to keep the encrypted message in
			  char justWork[inputLength];
			  //Set it's memory to \0
			  memset(justWork, '\0', inputLength);

			  //For the length of the plaintext
			  for(l = 0; l < inputLength; l++){

				//Take the first character of the message
				encInt = (int)encMsg[l];
				//Take the first character of the key
				keyInt = (int)keyMsg[l];

				//Subtract it by A
				encInt = encInt - (int)'A';
				//Subtract it by A
				keyInt = keyInt - (int)'A';

				//If it is less than 0 it's a space
				if(encInt < 0){
					encInt = 26;
				}
				//If it's less than 0 it's a space
				if(keyInt < 0){
					keyInt = 26;
				}

				//Add the two ints together
				theSecret = encInt + keyInt;
	
				//Mod it by 27 so that none of them are too big
				theSecret = theSecret % 27;
	
				//Add A back in
				theSecret = theSecret + (int)'A';

				//If the new number is 91 it's a space
				if(theSecret == 91){
					//Make it a space
					theSecret = (int)' ';
				}

				//Add the new number -> character into the
				//string
				justWork[l] = (char)theSecret;
			  }



			  //Clear out charswritten
			  charsWritten = 0;
			  //While not all of the message has been sent
			  while(charsWritten < inputLength){
				  //Send the encrypted message
				  charsWritten += send(establishedConnectionFD, justWork, inputLength - charsWritten, 0);
				  //If it doesn't send properly
				  if(charsWritten < 0){
					//Send an error
					error("ERROR writing to socket");
				  }
			  }



			  //Close the port
			  close(establishedConnectionFD);
			  //Say that it's done
			  return 0;
	  	}
		//Else
		else{
			//The message wasn't received properly so die
			close(establishedConnectionFD);
			//Retry
			return (1);
		}
	  }
 }
  //Close the listening	
  close(listenSocketFD);

  

  //Say that it's done
  return 0;
}
